GHOST MUSIC — Android starter project (v0.1.0)

WHAT THIS IS
- A starter Android Studio project that packages the Ghost Music mobile web interface inside an Android WebView.
- Interface features include local audio file selection, direct audio URL playback, search, favorites, shuffle, repeat, seek, and volume.
- Theme: black and gold.

HOW TO BUILD AN APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio, choose Open and select this folder (the folder containing settings.gradle).
4. Allow Gradle sync and install the required Android SDK if prompted.
5. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show where the APK was saved. Copy it to your Android phone and install it, allowing installation from that source if Android asks.

CURRENT LIMITATIONS / IMPORTANT
- This is starter source code, not a prebuilt or signed APK. It has not been compiled or device-tested in this environment.
- The local file picker relies on browser/WebView file input support; behaviour can vary by Android version.
- Direct online audio links must be reachable and allow playback. This is not a licensed streaming catalogue and does not bypass services such as Spotify/YouTube.
- This is not yet a true background audio service. Playback may stop when the app is backgrounded or the system suspends it.
- A proper production release needs Android media-session/background playback, native audio/equalizer integration, persistent library storage, permissions/testing, app icon/splash screen, and licensed APIs/catalogue for online discovery.
- Do not distribute copyrighted music without permission.

FILES
app/src/main/assets/index.html — app interface
app/src/main/java/com/ghostmusic/app/MainActivity.java — Android WebView activity
app/src/main/AndroidManifest.xml — app manifest
app/build.gradle — Android app build configuration
